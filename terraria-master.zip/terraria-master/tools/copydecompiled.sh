cp terraria/Decompiled/app.ico public/
cp -r terraria/Decompiled/{ReLogic,Terraria} terraria/
